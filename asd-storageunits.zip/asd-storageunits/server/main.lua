local QBCore = exports['qb-core']:GetCoreObject()

local ConfigMap = {}
local StorageCache = {}
local PurchaseLocks = {}
local InventoryHookRegistered = false
local ExpirationThreadStarted = false

local function DebugPrint(...)
    ASDStorage.DebugPrint('[server]', ...)
end

local function Notify(source, description, notifyType)
    TriggerClientEvent('ox_lib:notify', source, {
        title = Config.NotifyTitle,
        description = description,
        type = notifyType or 'inform'
    })
end

local function BuildConfigMap()
    ConfigMap = {}

    for index, unit in ipairs(Config.StorageUnits or {}) do
        if not ASDStorage.IsValidStorageId(unit.id) then
            print(('^1[asd-storageunits]^7 Invalid storage id at Config.StorageUnits[%s].'):format(index))
        elseif ConfigMap[unit.id] then
            print(('^1[asd-storageunits]^7 Duplicate storage id "%s" in config; ignoring duplicate.'):format(unit.id))
        else
            unit.price = ASDStorage.NumberInRange(unit.price, Config.MinPrice, Config.MaxPrice) or Config.MinPrice
            unit.rentalDays = ASDStorage.NumberInRange(unit.rentalDays, Config.MinRentalDays, Config.MaxRentalDays) or Config.MinRentalDays
            unit.slots = ASDStorage.NumberInRange(unit.slots, Config.MinSlots, Config.MaxSlots) or Config.MinSlots
            unit.weight = ASDStorage.NumberInRange(unit.weight, Config.MinWeight, Config.MaxWeight) or Config.MinWeight
            unit.label = ASDStorage.SanitizeLabel(unit.label or unit.id)

            if #unit.label < Config.MinLabelLength then unit.label = unit.id end
            if #unit.label > Config.MaxLabelLength then unit.label = unit.label:sub(1, Config.MaxLabelLength) end

            unit.blip = unit.blip or {}
            if unit.blip.enabled == nil then unit.blip.enabled = true end

            ConfigMap[unit.id] = unit
        end
    end
end

local function EnsureDatabase()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `asd_storageunits` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `storage_id` VARCHAR(64) NOT NULL,
            `owner_citizenid` VARCHAR(64) NULL DEFAULT NULL,
            `renter_citizenid` VARCHAR(64) NULL DEFAULT NULL,
            `label` VARCHAR(64) NOT NULL,
            `price` INT UNSIGNED NOT NULL DEFAULT 0,
            `rental_days` TINYINT UNSIGNED NOT NULL DEFAULT 7,
            `slots` SMALLINT UNSIGNED NOT NULL DEFAULT 50,
            `weight` INT UNSIGNED NOT NULL DEFAULT 100000,
            `locked` TINYINT(1) NOT NULL DEFAULT 0,
            `blip_enabled` TINYINT(1) NOT NULL DEFAULT 1,
            `expires_at` DATETIME NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_asd_storageunits_storage_id` (`storage_id`),
            KEY `idx_asd_storageunits_owner` (`owner_citizenid`),
            KEY `idx_asd_storageunits_renter` (`renter_citizenid`),
            KEY `idx_asd_storageunits_expires_at` (`expires_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ]])
end

local function EnsureConfiguredRows()
    for storageId, unit in pairs(ConfigMap) do
        local exists = MySQL.scalar.await('SELECT `storage_id` FROM `asd_storageunits` WHERE `storage_id` = ? LIMIT 1', { storageId })

        if not exists then
            MySQL.insert.await([[
                INSERT INTO `asd_storageunits`
                    (`storage_id`, `label`, `price`, `rental_days`, `slots`, `weight`, `locked`, `blip_enabled`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ]], {
                storageId,
                unit.label,
                unit.price,
                unit.rentalDays,
                unit.slots,
                unit.weight,
                ASDStorage.BoolToInt(unit.locked),
                ASDStorage.BoolToInt(unit.blip and unit.blip.enabled)
            })

            DebugPrint(('Inserted database row for configured storage %s.'):format(storageId))
        end
    end
end

local function NormalizeRow(row)
    local unit = ConfigMap[row.storage_id]
    if not unit then return nil end

    local label = ASDStorage.SanitizeLabel(row.label or unit.label)
    if #label < Config.MinLabelLength then label = unit.label end
    if #label > Config.MaxLabelLength then label = label:sub(1, Config.MaxLabelLength) end

    return {
        storage_id = row.storage_id,
        owner_citizenid = row.owner_citizenid ~= '' and row.owner_citizenid or nil,
        renter_citizenid = row.renter_citizenid ~= '' and row.renter_citizenid or nil,
        label = label,
        price = ASDStorage.NumberInRange(row.price, Config.MinPrice, Config.MaxPrice) or unit.price,
        rental_days = ASDStorage.NumberInRange(row.rental_days, Config.MinRentalDays, Config.MaxRentalDays) or unit.rentalDays,
        slots = ASDStorage.NumberInRange(row.slots, Config.MinSlots, Config.MaxSlots) or unit.slots,
        weight = ASDStorage.NumberInRange(row.weight, Config.MinWeight, Config.MaxWeight) or unit.weight,
        locked = ASDStorage.Bool(row.locked),
        blip_enabled = ASDStorage.Bool(row.blip_enabled),
        expires_at = row.expires_at
    }
end

local function LoadStorage(storageId)
    local row = MySQL.single.await('SELECT * FROM `asd_storageunits` WHERE `storage_id` = ? LIMIT 1', { storageId })
    if not row then return nil end

    local normalized = NormalizeRow(row)
    StorageCache[storageId] = normalized
    return normalized
end

local function LoadAllStorage()
    StorageCache = {}

    local rows = MySQL.query.await('SELECT * FROM `asd_storageunits`', {}) or {}
    for _, row in ipairs(rows) do
        if ConfigMap[row.storage_id] then
            StorageCache[row.storage_id] = NormalizeRow(row)
        end
    end

    DebugPrint(('Loaded %s configured storage units from database.'):format(#rows))
end

local function RegisterStorageStash(storage)
    if not storage then return false end

    local unit = ConfigMap[storage.storage_id]
    if not unit then return false end

    local stashId = ASDStorage.StashId(storage.storage_id)
    local ok, err = pcall(function()
        exports.ox_inventory:RegisterStash(
            stashId,
            storage.label,
            storage.slots,
            storage.weight,
            false,
            nil,
            unit.coords
        )
    end)

    if not ok then
        print(('^1[asd-storageunits]^7 Failed to register stash %s: %s'):format(stashId, err))
        return false
    end

    DebugPrint(('Registered stash %s (%s slots / %s weight).'):format(stashId, storage.slots, storage.weight))
    return true
end

local function RefreshStorageStash(storage)
    if not storage then return end

    local stashId = ASDStorage.StashId(storage.storage_id)

    -- RemoveInventory saves and unloads the runtime inventory, then RegisterStash recreates it with new label/slots/weight.
    pcall(function()
        exports.ox_inventory:RemoveInventory(stashId)
    end)

    RegisterStorageStash(storage)
end

local function RegisterAllStashes()
    for _, storage in pairs(StorageCache) do
        RegisterStorageStash(storage)
    end
end

local function ClearStorageInventory(storageId)
    local stashId = ASDStorage.StashId(storageId)

    local ok, err = pcall(function()
        exports.ox_inventory:ClearInventory(stashId)
        exports.ox_inventory:RemoveInventory(stashId)
    end)

    if not ok then
        print(('^3[asd-storageunits]^7 Could not clear stash %s: %s'):format(stashId, err))
    end
end

local function BroadcastRefresh()
    TriggerClientEvent('asd-storageunits:client:refresh', -1)
end

local function GetPlayer(source)
    return QBCore.Functions.GetPlayer(source)
end

local function GetCitizenId(source)
    local Player = GetPlayer(source)
    if not Player or not Player.PlayerData then return nil end
    return Player.PlayerData.citizenid
end

local function IsPlayerNearStorage(source, storageId)
    local unit = ConfigMap[storageId]
    if not unit or not unit.coords then return false end

    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end

    local playerCoords = GetEntityCoords(ped)
    return #(playerCoords - unit.coords) <= (Config.ServerInteractionDistance or 7.5)
end

local function PlayerOwnsStorage(source, storageId)
    local citizenid = GetCitizenId(source)
    local storage = StorageCache[storageId]

    return citizenid ~= nil and storage ~= nil and storage.owner_citizenid == citizenid
end

local function HasStorageAccess(source, storageId, checkDistance)
    local citizenid = GetCitizenId(source)
    local storage = StorageCache[storageId]

    if not citizenid or not storage then
        return false, 'Invalid storage unit.'
    end

    if checkDistance and not IsPlayerNearStorage(source, storageId) then
        return false, 'You are too far away from this storage unit.'
    end

    if storage.owner_citizenid == citizenid then
        return true
    end

    if storage.renter_citizenid == citizenid and not storage.locked then
        return true
    end

    if storage.locked then
        return false, 'This storage unit is locked.'
    end

    return false, 'You do not have access to this storage unit.'
end

local function ValidateStorageId(source, storageId)
    if not ASDStorage.IsValidStorageId(storageId) or not ConfigMap[storageId] or not StorageCache[storageId] then
        if source then Notify(source, 'Invalid storage unit.', 'error') end
        return nil
    end

    return storageId
end

local function GetBankingResource()
    local banking = tostring(Config.Banking or 'qb-banking'):lower()

    if banking ~= 'qb-banking' and banking ~= 'ps-banking' then
        print(('^3[asd-storageunits]^7 Invalid Config.Banking "%s". Falling back to qb-banking.'):format(tostring(Config.Banking)))
        banking = 'qb-banking'
    end

    return banking
end

local function IsResourceStarted(resourceName)
    return GetResourceState(resourceName) == 'started'
end

local function GetBankBalance(Player)
    if Player.Functions and Player.Functions.GetMoney then
        local ok, balance = pcall(function()
            return Player.Functions.GetMoney('bank')
        end)
        if ok and tonumber(balance) then return tonumber(balance) end
    end

    return tonumber(Player.PlayerData and Player.PlayerData.money and Player.PlayerData.money.bank) or 0
end

local function AddBankMoney(Player, amount, reason)
    if Player.Functions and Player.Functions.AddMoney then
        return Player.Functions.AddMoney('bank', amount, reason)
    end

    if Player.AddMoney then
        return Player.AddMoney('bank', amount, reason)
    end

    return false
end

local function RemoveBankMoney(Player, amount, reason)
    if Player.Functions and Player.Functions.RemoveMoney then
        return Player.Functions.RemoveMoney('bank', amount, reason)
    end

    if Player.RemoveMoney then
        return Player.RemoveMoney('bank', amount, reason)
    end

    return false
end

local function CreateQbBankingStatement(source, amount, reason, statementType)
    if not IsResourceStarted('qb-banking') then return false end

    local ok, result = pcall(function()
        return exports['qb-banking']:CreateBankStatement(
            source,
            'checking',
            amount,
            reason or 'Storage unit transaction',
            statementType,
            'player'
        )
    end)

    if not ok then
        print(('^3[asd-storageunits]^7 qb-banking statement failed: %s'):format(result))
        return false
    end

    return result == true
end

local function CreatePsBankingTransaction(Player, amount, reason, isIncome)
    if not IsResourceStarted('ps-banking') then return false end

    local citizenid = Player.PlayerData and Player.PlayerData.citizenid
    if not citizenid then return false end

    local ok, result = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO `ps_banking_transactions`
                (`identifier`, `description`, `type`, `amount`, `date`, `isIncome`)
            VALUES (?, ?, ?, ?, NOW(), ?)
        ]], {
            citizenid,
            reason or 'Storage unit transaction',
            isIncome and 'To account' or 'From account',
            math.abs(tonumber(amount) or 0),
            isIncome and 1 or 0
        })
    end)

    if not ok then
        print(('^3[asd-storageunits]^7 ps-banking transaction log failed: %s'):format(result))
        return false
    end

    return result ~= false
end

local function LogBankingTransaction(source, Player, amount, reason, isIncome)
    local banking = GetBankingResource()

    if banking == 'qb-banking' then
        CreateQbBankingStatement(source, amount, reason, isIncome and 'deposit' or 'withdraw')
    elseif banking == 'ps-banking' then
        CreatePsBankingTransaction(Player, amount, reason, isIncome)
    end
end

local function ChargePlayer(source, amount, reason)
    local Player = GetPlayer(source)
    if not Player then return false, 'Player not found.' end

    amount = tonumber(amount)
    if not amount or amount < 1 then return false, 'Invalid charge amount.' end

    if GetBankBalance(Player) < amount then
        return false, 'You do not have enough money.'
    end

    local removed = RemoveBankMoney(Player, amount, reason)
    if not removed then
        return false, 'Payment failed.'
    end

    LogBankingTransaction(source, Player, amount, reason, false)
    return true
end

local function RefundPlayer(source, amount, reason)
    local Player = GetPlayer(source)
    if not Player then return false end

    local added = AddBankMoney(Player, amount, reason)
    if added then
        LogBankingTransaction(source, Player, amount, reason, true)
    end

    return added
end

local function ResetStorageToConfig(storageId, expectedOwnerCitizenId)
    local unit = ConfigMap[storageId]
    if not unit then return false end

    local params = {
        unit.label,
        unit.price,
        unit.rentalDays,
        unit.slots,
        unit.weight,
        ASDStorage.BoolToInt(unit.locked),
        ASDStorage.BoolToInt(unit.blip and unit.blip.enabled),
        storageId
    }

    local ownerWhere = ''
    if expectedOwnerCitizenId then
        ownerWhere = ' AND `owner_citizenid` = ?'
        params[#params + 1] = expectedOwnerCitizenId
    end

    local affected = MySQL.update.await(([=[
        UPDATE `asd_storageunits`
        SET
            `owner_citizenid` = NULL,
            `renter_citizenid` = NULL,
            `label` = ?,
            `price` = ?,
            `rental_days` = ?,
            `slots` = ?,
            `weight` = ?,
            `locked` = ?,
            `blip_enabled` = ?,
            `expires_at` = NULL
        WHERE `storage_id` = ?%s
    ]=]):format(ownerWhere), params)

    if not affected or affected < 1 then
        return false
    end

    ClearStorageInventory(storageId)
    LoadStorage(storageId)
    RefreshStorageStash(StorageCache[storageId])

    return true
end

local function ResetExpiredUnits()
    local resetCount = 0
    local expired = MySQL.query.await([[
        SELECT `storage_id`
        FROM `asd_storageunits`
        WHERE `owner_citizenid` IS NOT NULL
          AND `expires_at` IS NOT NULL
          AND `expires_at` <= NOW()
    ]], {}) or {}

    for _, row in ipairs(expired) do
        if ConfigMap[row.storage_id] then
            if ResetStorageToConfig(row.storage_id) then
                resetCount = resetCount + 1
                DebugPrint(('Reset expired storage unit %s.'):format(row.storage_id))
            end
        end
    end

    return resetCount
end

local function ValidateEditPayload(payload)
    if type(payload) ~= 'table' then return nil, 'Invalid input.' end

    local price = ASDStorage.NumberInRange(payload.price, Config.MinPrice, Config.MaxPrice)
    local rentalDays = ASDStorage.NumberInRange(payload.rentalDays, Config.MinRentalDays, Config.MaxRentalDays)
    local slots = ASDStorage.NumberInRange(payload.slots, Config.MinSlots, Config.MaxSlots)
    local weight = ASDStorage.NumberInRange(payload.weight, Config.MinWeight, Config.MaxWeight)
    local label = ASDStorage.SanitizeLabel(payload.label)

    if not price then return nil, ('Price must be between $%s and $%s.'):format(Config.MinPrice, Config.MaxPrice) end
    if not rentalDays then return nil, ('Rental days must be between %s and %s.'):format(Config.MinRentalDays, Config.MaxRentalDays) end
    if not slots then return nil, ('Slots must be between %s and %s.'):format(Config.MinSlots, Config.MaxSlots) end
    if not weight then return nil, ('Weight must be between %s and %s.'):format(Config.MinWeight, Config.MaxWeight) end
    if #label < Config.MinLabelLength or #label > Config.MaxLabelLength then
        return nil, ('Label must be %s-%s characters.'):format(Config.MinLabelLength, Config.MaxLabelLength)
    end

    return {
        price = price,
        rentalDays = rentalDays,
        slots = slots,
        weight = weight,
        label = label,
        blipEnabled = payload.blipEnabled == true
    }
end

local function RegisterInventoryHook()
    if InventoryHookRegistered then return end
    InventoryHookRegistered = true

    local escapedPrefix = (Config.StashPrefix or 'asd_storage_'):gsub('([%^%$%(%)%%%.%[%]%*%+%-%?])', '%%%1')

    exports.ox_inventory:registerHook('openInventory', function(payload)
        if not payload or payload.inventoryType ~= 'stash' then return true end

        local storageId = ASDStorage.StorageIdFromStashId(tostring(payload.inventoryId))
        if not storageId then return true end

        local allowed = HasStorageAccess(payload.source, storageId, true)
        if not allowed then
            return false
        end

        return true
    end, {
        inventoryFilter = { '^' .. escapedPrefix }
    })

    DebugPrint('Registered ox_inventory openInventory access hook.')
end

local function StartExpirationThread()
    if ExpirationThreadStarted or not Config.EnableExpiration then return end
    ExpirationThreadStarted = true

    CreateThread(function()
        local interval = math.max(1, tonumber(Config.ExpirationCheckMinutes) or 30) * 60000

        while true do
            Wait(interval)

            local resetCount = ResetExpiredUnits()
            if resetCount and resetCount > 0 then
                BroadcastRefresh()
                DebugPrint(('Reset %s expired storage unit(s).'):format(resetCount))
            end
        end
    end)
end


lib.callback.register('asd-storageunits:server:getStorageData', function(source)
    local citizenid = GetCitizenId(source)
    local data = {}

    for storageId, storage in pairs(StorageCache) do
        local public = ASDStorage.ClonePublic(storage)
        public.isOwner = citizenid ~= nil and storage.owner_citizenid == citizenid
        public.isRenter = citizenid ~= nil and storage.renter_citizenid == citizenid
        public.canOpen = public.isOwner or (public.isRenter and not storage.locked)
        data[storageId] = public
    end

    return data
end)

lib.callback.register('asd-storageunits:server:buyStorage', function(source, storageId, expectedPrice)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    if PurchaseLocks[storageId] then
        Notify(source, 'This storage unit is being processed. Try again.', 'error')
        return false
    end

    PurchaseLocks[storageId] = true

    local ok, result = pcall(function()
        local storage = StorageCache[storageId]
        local citizenid = GetCitizenId(source)

        if not citizenid then
            Notify(source, 'Player data not loaded.', 'error')
            return false
        end

        if not IsPlayerNearStorage(source, storageId) then
            Notify(source, 'You are too far away from this storage unit.', 'error')
            return false
        end

        if storage.owner_citizenid then
            Notify(source, 'This storage unit is already owned.', 'error')
            return false
        end

        expectedPrice = tonumber(expectedPrice)
        if not expectedPrice or expectedPrice ~= storage.price then
            Notify(source, 'Storage price changed. Please try again.', 'error')
            return false
        end

        local charged, chargeError = ChargePlayer(source, storage.price, ('Storage unit purchase: %s'):format(storageId))
        if not charged then
            Notify(source, chargeError or 'You do not have enough money.', 'error')
            return false
        end

        local purchaseSql = ([=[
            UPDATE `asd_storageunits`
            SET
                `owner_citizenid` = ?,
                `renter_citizenid` = NULL,
                `locked` = 0,
                `expires_at` = DATE_ADD(NOW(), INTERVAL %d DAY)
            WHERE `storage_id` = ?
              AND (`owner_citizenid` IS NULL OR `owner_citizenid` = '')
        ]=]):format(storage.rental_days)

        local affected = MySQL.update.await(purchaseSql, { citizenid, storageId })

        if not affected or affected < 1 then
            RefundPlayer(source, storage.price, ('Storage unit purchase refund: %s'):format(storageId))
            Notify(source, 'This storage unit is already owned.', 'error')
            return false
        end

        LoadStorage(storageId)
        RefreshStorageStash(StorageCache[storageId])
        BroadcastRefresh()

        Notify(source, 'Storage purchased successfully.', 'success')
        DebugPrint(('%s purchased %s for $%s.'):format(citizenid, storageId, storage.price))
        return true
    end)

    PurchaseLocks[storageId] = nil

    if not ok then
        print(('^1[asd-storageunits]^7 buyStorage error for %s: %s'):format(storageId, result))
        Notify(source, 'An unexpected error occurred.', 'error')
        return false
    end

    return result
end)

lib.callback.register('asd-storageunits:server:openStorage', function(source, storageId)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    local allowed, message = HasStorageAccess(source, storageId, true)
    if not allowed then
        Notify(source, message or 'You do not have access to this storage unit.', 'error')
        return false
    end

    RegisterStorageStash(StorageCache[storageId])
    TriggerClientEvent('ox_inventory:openInventory', source, 'stash', ASDStorage.StashId(storageId))
    return true
end)

lib.callback.register('asd-storageunits:server:editStorage', function(source, storageId, payload)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    if not PlayerOwnsStorage(source, storageId) then
        Notify(source, 'You do not own this storage unit.', 'error')
        return false
    end

    if not IsPlayerNearStorage(source, storageId) then
        Notify(source, 'You are too far away from this storage unit.', 'error')
        return false
    end

    local values, errorMessage = ValidateEditPayload(payload)
    if not values then
        Notify(source, errorMessage or 'Invalid input.', 'error')
        return false
    end

    local citizenid = GetCitizenId(source)
    local affected = MySQL.update.await([[
        UPDATE `asd_storageunits`
        SET
            `label` = ?,
            `price` = ?,
            `rental_days` = ?,
            `slots` = ?,
            `weight` = ?,
            `blip_enabled` = ?
        WHERE `storage_id` = ?
          AND `owner_citizenid` = ?
    ]], {
        values.label,
        values.price,
        values.rentalDays,
        values.slots,
        values.weight,
        ASDStorage.BoolToInt(values.blipEnabled),
        storageId,
        citizenid
    })

    if not affected or affected < 1 then
        Notify(source, 'Storage settings could not be updated.', 'error')
        return false
    end

    LoadStorage(storageId)
    RefreshStorageStash(StorageCache[storageId])
    BroadcastRefresh()

    Notify(source, 'Storage settings updated.', 'success')
    return true
end)

lib.callback.register('asd-storageunits:server:removeRenter', function(source, storageId)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    local storage = StorageCache[storageId]

    if not PlayerOwnsStorage(source, storageId) then
        Notify(source, 'You do not own this storage unit.', 'error')
        return false
    end

    if not storage.renter_citizenid then
        Notify(source, 'No renter exists for this storage unit.', 'error')
        return false
    end

    local affected = MySQL.update.await([[
        UPDATE `asd_storageunits`
        SET `renter_citizenid` = NULL
        WHERE `storage_id` = ?
          AND `owner_citizenid` = ?
    ]], { storageId, GetCitizenId(source) })

    if not affected or affected < 1 then
        Notify(source, 'Renter could not be removed.', 'error')
        return false
    end

    LoadStorage(storageId)
    BroadcastRefresh()

    Notify(source, 'Renter removed.', 'success')
    return true
end)

lib.callback.register('asd-storageunits:server:toggleLock', function(source, storageId)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    local storage = StorageCache[storageId]

    if not PlayerOwnsStorage(source, storageId) then
        Notify(source, 'You do not own this storage unit.', 'error')
        return false
    end

    if not IsPlayerNearStorage(source, storageId) then
        Notify(source, 'You are too far away from this storage unit.', 'error')
        return false
    end

    local newLocked = not storage.locked
    local affected = MySQL.update.await([[
        UPDATE `asd_storageunits`
        SET `locked` = ?
        WHERE `storage_id` = ?
          AND `owner_citizenid` = ?
    ]], { ASDStorage.BoolToInt(newLocked), storageId, GetCitizenId(source) })

    if not affected or affected < 1 then
        Notify(source, 'Lock state could not be changed.', 'error')
        return false
    end

    LoadStorage(storageId)
    BroadcastRefresh()

    Notify(source, newLocked and 'Storage locked.' or 'Storage unlocked.', 'success')
    return true
end)

lib.callback.register('asd-storageunits:server:deleteStorage', function(source, storageId)
    storageId = ValidateStorageId(source, storageId)
    if not storageId then return false end

    if not PlayerOwnsStorage(source, storageId) then
        Notify(source, 'You do not own this storage unit.', 'error')
        return false
    end

    if not IsPlayerNearStorage(source, storageId) then
        Notify(source, 'You are too far away from this storage unit.', 'error')
        return false
    end

    local ok = ResetStorageToConfig(storageId, GetCitizenId(source))
    if not ok then
        Notify(source, 'Storage could not be deleted.', 'error')
        return false
    end

    BroadcastRefresh()
    Notify(source, 'Storage deleted.', 'success')
    return true
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    CreateThread(function()
        Wait(500)

        BuildConfigMap()

        local bankingResource = GetBankingResource()
        if not IsResourceStarted(bankingResource) then
            print(('^3[asd-storageunits]^7 Config.Banking is set to %s, but that resource is not started. Payments will still use QBCore bank money, but transaction logging may not appear.'):format(bankingResource))
        end

        if Config.AutoCreateDatabase then
            EnsureDatabase()
        end

        EnsureConfiguredRows()

        if Config.EnableExpiration then
            ResetExpiredUnits()
        end

        LoadAllStorage()
        RegisterAllStashes()
        RegisterInventoryHook()
        StartExpirationThread()
        BroadcastRefresh()

        print(('^2[asd-storageunits]^7 Loaded %s configured storage unit(s). Author: /asd'):format(#Config.StorageUnits))
    end)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    pcall(function()
        exports.ox_inventory:removeHooks()
    end)
end)
