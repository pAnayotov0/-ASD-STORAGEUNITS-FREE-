Config = Config or {}

Config.Debug = false

-- Creates the SQL table automatically on resource start. You should still import sql/asd_storageunits.sql in production.
Config.AutoCreateDatabase = true

Config.TargetDistance = 2.0
Config.ServerInteractionDistance = 7.5

Config.StashPrefix = 'asd_storage_'
Config.NotifyTitle = 'Storage Units'

-- Banking integration used for bank purchases/refunds.
-- Options: 'qb-banking' or 'ps-banking'
Config.Banking = 'qb-banking'

-- Hard validation limits. Keep these realistic for your server economy/inventory balance.
Config.MinPrice = 1
Config.MaxPrice = 100000000
Config.MinRentalDays = 1
Config.MaxRentalDays = 30
Config.MinSlots = 1
Config.MaxSlots = 500
Config.MinWeight = 1000
Config.MaxWeight = 30000000
Config.MinLabelLength = 3
Config.MaxLabelLength = 64

-- If true, owned units are reset when expires_at passes. Buying sets expires_at from rentalDays.
-- Expiration clears ownership/renter/custom settings and clears the stash inventory.
Config.EnableExpiration = true
Config.ExpirationCheckMinutes = 30

Config.StorageUnits = {
    {
        id = 'storage_1',
        label = 'Storage Unit 1',
        coords = vec3(-73.43, -1196.78, 28.12),
        target = {
            length = 2.0,
            width = 2.0,
            heading = 0.0,
            minZ = 27.12,
            maxZ = 29.12
        },
        price = 30000,
        rentalDays = 7,
        slots = 50,
        weight = 100000,
        locked = false,
        blip = {
            enabled = true,
            sprite = 587,
            color = 2,
            scale = 0.7,
            label = 'Available Storage Unit'
        }
    },
    {
        id = 'storage_2',
        label = 'Storage Unit 2',
        coords = vec3(-67.19, -1199.02, 28.09),
        target = {
            length = 2.0,
            width = 2.0,
            heading = 0.0,
            minZ = 27.09,
            maxZ = 29.09
        },
        price = 30000,
        rentalDays = 7,
        slots = 50,
        weight = 100000,
        locked = false,
        blip = {
            enabled = true,
            sprite = 587,
            color = 2,
            scale = 0.7,
            label = 'Available Storage Unit'
        }
    },
    {
        id = 'storage_3',
        label = 'Storage Unit 3',
        coords = vec3(-61.32, -1204.89, 28.32),
        target = {
            length = 2.0,
            width = 2.0,
            heading = 0.0,
            minZ = 27.32,
            maxZ = 29.32
        },
        price = 30000,
        rentalDays = 7,
        slots = 50,
        weight = 100000,
        locked = false,
        blip = {
            enabled = true,
            sprite = 587,
            color = 2,
            scale = 0.7,
            label = 'Available Storage Unit'
        }
    },
    {
        id = 'storage_4',
        label = 'Storage Unit 4',
        coords = vec3(-71.47, -1206.34, 28.22),
        target = {
            length = 2.0,
            width = 2.0,
            heading = 0.0,
            minZ = 27.22,
            maxZ = 29.22
        },
        price = 30000,
        rentalDays = 7,
        slots = 50,
        weight = 100000,
        locked = false,
        blip = {
            enabled = true,
            sprite = 587,
            color = 2,
            scale = 0.7,
            label = 'Available Storage Unit'
        }
    },
    {
        id = 'storage_5',
        label = 'Storage Unit 5',
        coords = vec3(-65.94, -1211.94, 28.76),
        target = {
            length = 2.0,
            width = 2.0,
            heading = 0.0,
            minZ = 27.76,
            maxZ = 29.76
        },
        price = 30000,
        rentalDays = 7,
        slots = 50,
        weight = 100000,
        locked = false,
        blip = {
            enabled = true,
            sprite = 587,
            color = 2,
            scale = 0.7,
            label = 'Available Storage Unit'
        }
    }
}
