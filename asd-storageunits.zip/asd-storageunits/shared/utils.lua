ASDStorage = ASDStorage or {}

function ASDStorage.DebugPrint(...)
    if not Config or not Config.Debug then return end
    print(('^3[%s]^7'):format(GetCurrentResourceName()), ...)
end

function ASDStorage.Trim(value)
    if type(value) ~= 'string' then return '' end
    return value:match('^%s*(.-)%s*$') or ''
end

function ASDStorage.SanitizeLabel(value)
    value = ASDStorage.Trim(value)
    value = value:gsub('[\r\n\t]', ' ')
    value = value:gsub('%s+', ' ')
    return value
end

function ASDStorage.IsValidStorageId(storageId)
    return type(storageId) == 'string'
        and #storageId >= 1
        and #storageId <= 64
        and storageId:match('^[%w_%-]+$') ~= nil
end

function ASDStorage.StashId(storageId)
    return ('%s%s'):format(Config.StashPrefix or 'asd_storage_', storageId)
end

function ASDStorage.StorageIdFromStashId(stashId)
    if type(stashId) ~= 'string' then return nil end

    local prefix = Config.StashPrefix or 'asd_storage_'
    if stashId:sub(1, #prefix) ~= prefix then return nil end

    local storageId = stashId:sub(#prefix + 1)
    if not ASDStorage.IsValidStorageId(storageId) then return nil end

    return storageId
end

function ASDStorage.Bool(value)
    return value == true or value == 1 or value == '1'
end

function ASDStorage.BoolToInt(value)
    return ASDStorage.Bool(value) and 1 or 0
end

function ASDStorage.NumberInRange(value, min, max)
    local number = tonumber(value)
    if not number then return nil end

    number = math.floor(number)
    if number < min or number > max then return nil end

    return number
end

function ASDStorage.ClonePublic(storage)
    return {
        id = storage.storage_id,
        label = storage.label,
        price = storage.price,
        rentalDays = storage.rental_days,
        slots = storage.slots,
        weight = storage.weight,
        locked = storage.locked,
        blipEnabled = storage.blip_enabled,
        owned = storage.owner_citizenid ~= nil and storage.owner_citizenid ~= '',
        hasRenter = storage.renter_citizenid ~= nil and storage.renter_citizenid ~= '',
        expiresAt = storage.expires_at
    }
end
