fx_version 'cerulean'
game 'gta5'

name 'asd-storageunits'
description 'QBCore storage unit system using ox_target, ox_inventory, ox_lib, configurable banking, and oxmysql'
author '/asd'
version '1.0.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'shared/utils.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

dependencies {
    'qb-core',
    'ox_lib',
    'ox_target',
    'ox_inventory',
    'oxmysql'
}
