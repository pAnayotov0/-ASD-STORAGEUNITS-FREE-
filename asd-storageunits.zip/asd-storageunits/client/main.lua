local QBCore = exports['qb-core']:GetCoreObject()

local StorageState = {}
local Zones = {}
local Blips = {}
local PlayerData = {}
local ResourceName = GetCurrentResourceName()

local function DebugPrint(...)
    ASDStorage.DebugPrint('[client]', ...)
end

local function Notify(description, notifyType)
    lib.notify({
        title = Config.NotifyTitle,
        description = description,
        type = notifyType or 'inform'
    })
end

local function FormatMoney(amount)
    amount = tonumber(amount) or 0
    local formatted = tostring(math.floor(amount))

    while true do
        local k
        formatted, k = formatted:gsub('^(-?%d+)(%d%d%d)', '%1,%2')
        if k == 0 then break end
    end

    return formatted
end

local function GetStorageConfig(storageId)
    for _, storage in ipairs(Config.StorageUnits or {}) do
        if storage.id == storageId then
            return storage
        end
    end
end

local function RemoveAllBlips()
    for storageId, blip in pairs(Blips) do
        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
        Blips[storageId] = nil
    end
end

local function RefreshBlips()
    RemoveAllBlips()

    for _, cfg in ipairs(Config.StorageUnits or {}) do
        local state = StorageState[cfg.id]
        local blipCfg = cfg.blip or {}

        if state and not state.owned and state.blipEnabled and blipCfg.enabled then
            local blip = AddBlipForCoord(cfg.coords.x, cfg.coords.y, cfg.coords.z)
            SetBlipSprite(blip, blipCfg.sprite or 473)
            SetBlipColour(blip, blipCfg.color or 2)
            SetBlipScale(blip, blipCfg.scale or 0.7)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentString(state.label or cfg.label or blipCfg.label or 'Storage Unit')
            EndTextCommandSetBlipName(blip)

            Blips[cfg.id] = blip
        end
    end
end

local function RefreshStorageData()
    local ok, data = pcall(function()
        return lib.callback.await('asd-storageunits:server:getStorageData', false)
    end)

    if not ok then
        print(('^1[asd-storageunits]^7 Failed to refresh storage data: %s'):format(data))
        return
    end

    if type(data) ~= 'table' then return end

    StorageState = data
    RefreshBlips()
    DebugPrint('Storage state refreshed.')
end

local function OpenStorage(storageId)
    lib.callback.await('asd-storageunits:server:openStorage', false, storageId)
end

local function OpenEditDialog(storageId)
    local state = StorageState[storageId]
    if not state or not state.isOwner then
        Notify('You do not own this storage unit.', 'error')
        return
    end

    local input = lib.inputDialog(('Edit %s'):format(state.label or 'Storage'), {
        {
            type = 'number',
            label = 'Storage sale/rental price',
            default = state.price or Config.MinPrice,
            min = Config.MinPrice,
            max = Config.MaxPrice,
            required = true
        },
        {
            type = 'input',
            label = 'Storage label',
            default = state.label or '',
            required = true,
            min = Config.MinLabelLength,
            max = Config.MaxLabelLength
        },
        {
            type = 'checkbox',
            label = 'Blip enabled',
            checked = state.blipEnabled == true
        },
        {
            type = 'slider',
            label = 'Rental days',
            default = state.rentalDays or Config.MinRentalDays,
            min = Config.MinRentalDays,
            max = Config.MaxRentalDays,
            step = 1,
            required = true
        },
        {
            type = 'number',
            label = 'Inventory slots',
            default = state.slots or Config.MinSlots,
            min = Config.MinSlots,
            max = Config.MaxSlots,
            required = true
        },
        {
            type = 'number',
            label = 'Inventory weight limit',
            default = state.weight or Config.MinWeight,
            min = Config.MinWeight,
            max = Config.MaxWeight,
            required = true
        }
    })

    if not input then return end

    lib.callback.await('asd-storageunits:server:editStorage', false, storageId, {
        price = input[1],
        label = input[2],
        blipEnabled = input[3] == true,
        rentalDays = input[4],
        slots = input[5],
        weight = input[6]
    })
end

local function RemoveRenter(storageId)
    lib.callback.await('asd-storageunits:server:removeRenter', false, storageId)
end

local function ToggleLock(storageId)
    lib.callback.await('asd-storageunits:server:toggleLock', false, storageId)
end

local function DeleteStorage(storageId)
    local response = lib.alertDialog({
        header = 'Delete Storage',
        content = 'Are you sure you want to delete this storage unit? This action cannot be undone.',
        centered = true,
        cancel = true,
        labels = {
            confirm = 'Yes',
            cancel = 'No'
        }
    })

    if response ~= 'confirm' then return end

    lib.callback.await('asd-storageunits:server:deleteStorage', false, storageId)
end

local function OpenManageMenu(storageId)
    local state = StorageState[storageId]
    if not state or not state.isOwner then
        Notify('You do not own this storage unit.', 'error')
        return
    end

    local contextId = ('asd_storageunits_manage_%s'):format(storageId)

    lib.registerContext({
        id = contextId,
        title = state.label or 'Storage Unit',
        options = {
            {
                title = 'Open Storage',
                description = ('Slots: %s | Weight: %s'):format(state.slots or 0, state.weight or 0),
                icon = 'box-open',
                onSelect = function()
                    OpenStorage(storageId)
                end
            },
            {
                title = 'Edit Storage',
                description = 'Change price, label, blip, rental days, slots, and weight.',
                icon = 'pen-to-square',
                onSelect = function()
                    OpenEditDialog(storageId)
                end
            },
            {
                title = 'Remove Renter',
                description = state.hasRenter and 'Remove the current renter from this unit.' or 'No renter is currently assigned.',
                icon = 'user-minus',
                disabled = not state.hasRenter,
                onSelect = function()
                    RemoveRenter(storageId)
                end
            },
            {
                title = state.locked and 'Unlock Storage' or 'Lock Storage',
                description = state.locked and 'Allow an assigned renter to open this storage.' or 'Prevent renters from opening this storage.',
                icon = state.locked and 'lock-open' or 'lock',
                onSelect = function()
                    ToggleLock(storageId)
                end
            },
            {
                title = 'Delete Storage',
                description = 'Reset ownership and clear this storage stash.',
                icon = 'trash',
                onSelect = function()
                    DeleteStorage(storageId)
                end
            }
        }
    })

    lib.showContext(contextId)
end

local function BuyStorage(storageId)
    local state = StorageState[storageId]
    if not state then
        Notify('Storage data is still loading. Try again.', 'error')
        return
    end

    if state.owned then
        Notify('This storage unit is already owned.', 'error')
        return
    end

    local response = lib.alertDialog({
        header = 'Buy Storage',
        content = ('Are you sure you want to buy this storage unit for $%s?'):format(FormatMoney(state.price)),
        centered = true,
        cancel = true,
        labels = {
            confirm = 'Yes',
            cancel = 'No'
        }
    })

    if response ~= 'confirm' then return end

    lib.callback.await('asd-storageunits:server:buyStorage', false, storageId, state.price)
end

local function RemoveAllZones()
    for storageId, zoneId in pairs(Zones) do
        pcall(function()
            exports.ox_target:removeZone(zoneId)
        end)
        Zones[storageId] = nil
    end
end

local function CreateStorageZone(cfg)
    if Zones[cfg.id] then return end

    local target = cfg.target or {}
    local length = tonumber(target.length) or 2.0
    local width = tonumber(target.width) or 2.0
    local minZ = tonumber(target.minZ)
    local maxZ = tonumber(target.maxZ)
    local zSize = 2.0
    local zCoord = cfg.coords.z

    if minZ and maxZ and maxZ > minZ then
        zCoord = (minZ + maxZ) / 2.0
        zSize = maxZ - minZ
    end

    local storageId = cfg.id

    local zoneId = exports.ox_target:addBoxZone({
        coords = vec3(cfg.coords.x, cfg.coords.y, zCoord),
        name = ('asd_storageunits_%s'):format(storageId),
        size = vec3(length, width, zSize),
        rotation = tonumber(target.heading) or 0.0,
        debug = Config.Debug,
        options = {
            {
                name = ('asd_storageunits_buy_%s'):format(storageId),
                label = 'Buy Storage',
                icon = 'fa-solid fa-warehouse',
                distance = Config.TargetDistance,
                canInteract = function()
                    local state = StorageState[storageId]
                    return state ~= nil and not state.owned
                end,
                onSelect = function()
                    BuyStorage(storageId)
                end
            },
            {
                name = ('asd_storageunits_manage_%s'):format(storageId),
                label = 'Manage Storage',
                icon = 'fa-solid fa-boxes-stacked',
                distance = Config.TargetDistance,
                canInteract = function()
                    local state = StorageState[storageId]
                    return state ~= nil and state.isOwner == true
                end,
                onSelect = function()
                    OpenManageMenu(storageId)
                end
            },
            {
                name = ('asd_storageunits_open_renter_%s'):format(storageId),
                label = 'Open Storage',
                icon = 'fa-solid fa-box-open',
                distance = Config.TargetDistance,
                canInteract = function()
                    local state = StorageState[storageId]
                    return state ~= nil and state.isRenter == true and state.locked == false and state.isOwner ~= true
                end,
                onSelect = function()
                    OpenStorage(storageId)
                end
            }
        }
    })

    Zones[storageId] = zoneId
    DebugPrint(('Created target zone for %s.'):format(storageId))
end

local function CreateAllZones()
    for _, cfg in ipairs(Config.StorageUnits or {}) do
        if ASDStorage.IsValidStorageId(cfg.id) then
            CreateStorageZone(cfg)
        end
    end
end

RegisterNetEvent('asd-storageunits:client:refresh', function()
    SetTimeout(250, RefreshStorageData)
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
    RefreshStorageData()
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    PlayerData = {}
    StorageState = {}
    RefreshBlips()
end)

RegisterNetEvent('QBCore:Player:SetPlayerData', function(data)
    PlayerData = data or {}
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= ResourceName then return end

    RemoveAllZones()
    RemoveAllBlips()
end)

CreateThread(function()
    while not QBCore do Wait(100) end

    PlayerData = QBCore.Functions.GetPlayerData() or {}

    CreateAllZones()
    Wait(500)
    RefreshStorageData()
end)
